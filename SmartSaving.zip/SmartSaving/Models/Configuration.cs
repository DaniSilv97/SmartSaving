﻿namespace SmartSaving.Models {
    public class Configuration {
        public string ConnectionString { get; set; }
        public string SmtpIp { get; set; }
        public string UsesTLS { get; set; }

    }
}
