﻿namespace SmartSaving.Models {
    public class BaseHelper {
        protected readonly string Conector = Program.Conector;
    }
}
